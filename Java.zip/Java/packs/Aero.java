import packs.Benz;
class Aero
{
    public static void main(String args[])
    {
        Benz obj=new Benz();
        obj.disp();
    }
}