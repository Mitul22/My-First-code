package packs;
public class Benz
{
    public void disp()
    {
        System.out.println("This is used defined java package!!");
    }
    public static void main(String args[])
    {
        System.out.println("This is users package in Java!");
    }
}