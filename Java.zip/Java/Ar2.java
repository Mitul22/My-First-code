import java.util.Scanner;
class Ar2 
{
    public static void main(String args[])
    {
        int [] b= new int [4];
        Scanner obj=new Scanner(System.in);
        for(int i=0;i<b.length;i++)
        {
            b[i]=obj.nextInt();
        }
        Ar2 ob=new Ar2();
        Ar2.printArray(b);
    }
    static void printArray(int arr[])
    {
        int a=arr[0];
        for(int i=0;i<arr.length;i++)
        {
            if(a>arr[i])
            arr[i]=a;
            System.out.println(arr[i]);
        }
    }
}