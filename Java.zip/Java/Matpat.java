import java.util.Scanner;
class Matpat 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        System.out.println("Enter no. of rows=>");
        int rows=obj.nextInt();
        int n=1,i,j;
        for(i=1;i<rows;i++)
        {
            for(j=1;j<=i;j++)
            {
                System.out.print(n+" ");
                ++n;
            }
            System.out.println();
        }
        
    }
}