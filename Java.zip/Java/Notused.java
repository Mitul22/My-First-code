import java.util.Scanner;
class Notused 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        // char n=obj.next().charAt(0);
        // char [] use =new char []{'0','1','2','3','4','5','6','7','8','9'};
        // int h,t,u;
        // int flag=0;
        // for(h=0;h<=9;h++)
        // for(t=1;t<=9;t++)
        // for(u=1;u<=9;u++)
        // {
        //     if(use[h]+use[t]+use[u]==n)
        //     {
        //         flag=1;
        //     }
        //     else{
        //        flag=0;
        //     }
        // }
        // if(flag==1)
        // {
        //     System.out.println("Allnumbers are used");
        // }
        // else
        // {
        //     System.out.print("All numbers not used");
        // }
        
    }
}