import java.util.Scanner;
class Par 
{
    int len;
    int brea;
    void disp(int len,int brea,int hei)
    {
        this.len=len;
        this.brea=brea;
        System.out.println("Area of the room is "+(len*brea+brea*hei+hei*len)+" units");
    }
}
class Run extends Par
{
    int hei;
   void disp(int len,int brea,int hei)
    {
        this.hei=hei;
        System.out.println("Area of the room is "+(len*brea+brea*hei+hei*len)+" units");
    }
}
class Morphtime extends Run
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the length of room=>\t");
        int len=sc.nextInt();
        System.out.println("Enter the breadth of room=>\t");
        int brea=sc.nextInt();
        System.out.println("Enter the height of room=>\t");
        int hei=sc.nextInt();
        Par obj=new Run();  //Runtime Polymorphism
      obj.disp(len,brea,hei);
    }
}