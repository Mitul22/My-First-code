class Overload
{
    int Overload(int num)
    {
        int rev=0,rem=0;
        while(num>0)
        {
            rem=num%10;
            rev=rev*10+rem;
            num= num/10;
        }
        return rev;
    }
    int Overload(int a,int b)
    {
        int res=0;
        res=(a/b)+2;
        return res;
    }
    public static void main(String args[])
    {
        Overload obj=new Overload();
        System.out.println(obj.Overload(124));
        System.out.println(obj.Overload(23,56));
    }
}