package pack;
public class Pacs
{
    public void disp()
    {
        System.out.println("This is package 1");
    }
}
public class Person
{
    public void show()
    {
        System.out.println("This is package 2");
    }
}