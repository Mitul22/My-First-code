class finalj 
{
   
    public static void main(String args[])
    {
       int id=20988;
    System.out.println(id);
        
    }
}
class set 
{
    final int id=1010;
}