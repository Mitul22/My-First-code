import java.util.Scanner;
// import java.lang.Math;
class Automorph 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        System.out.println("Enter a number=>\t");
        int n=obj.nextInt();
        int num=n;
        int sq=n*n;
        int count=0;
        // int power;
        while(num>0)
        {
           count++;
           num/=10;
        }
        System.out.println("Count of numbere=>"+count);
            //   power=(int)(Math.pow(10,count));
          int  rem=(int)(sq%(Math.pow(10,count)));
          if(rem==n)
          {
              System.out.println("Automorphic number");
          }
          else{
              System.out.println("Not Automorphic number");
    }
}
}