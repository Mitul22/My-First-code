import java.util.Scanner;
class Publication
{
     public static void main(String args[])
     {
    Scanner obj=new Scanner(System.in);
    String title=obj.nextLine();
     String author=obj.nextLine();
int price=obj.nextInt();
 int pages=obj.nextInt();
   // public Publication ob=new Publication();
    Book ob=new Book(title,price,pages,author);
     }
}
class Book extends Publication
{
    
    // String title;
    // int price;
    // int pages;
    // String auhor;
    void putdata()
      {
        String title;
        int price;
        int pages;
        String auhor;
      System.out.println("Book Title "+title+" ,written by "+author+" has "+pages+" pages "+" and of "+price+" rupees.");
      }
   public   Book(String title,int price,int pages,String author)
     { 
        // this.title=title;
        // this.price=price;
        // this.pages=pages;
        // this.author=author;
     }
}