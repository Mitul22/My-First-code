class Def
{
    int a,b;
    Def()
    {
        System.out.println("Hello this is default constructor=>\t");
        a=10;
        b=20;
    }
    void disp()
    {
        System.out.println(a+b);
    }
    public static void main(String args[])
    {
        Def obj=new Def();
        obj.disp();
    }
}