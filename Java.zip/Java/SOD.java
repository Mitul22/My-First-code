import java.util.Scanner;
class SOD
{
  public static void main(String args[])
  {
    int sum=0,rem=0;
    Scanner obj=new Scanner(System.in);
    System.out.println("Enter a number=>\n");
    int n=obj.nextInt();
    while(n!=0)
    {
      rem=n%10;
      sum=sum+rem;
      n=n/10; 
    } 
    System.out.println("---------------\nSum of Digits in Java:)");
    System.out.println(sum);
  }
}