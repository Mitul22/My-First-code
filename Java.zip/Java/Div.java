class Div 
{
    public static void main(String args[])
    {
        int num=3;
        int x=2;
        int div=num/x;
        int rem=num-div*x;
        System.out.print(rem);
    }
}