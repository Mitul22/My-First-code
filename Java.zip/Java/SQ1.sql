create table Info(name varchar(50),lastname varchar(50),id number,salary number);
insert into Info
values('Ram','Murthy',01,12000000);
insert into Info
values('Sridhar','Chinappa',02,13045000);
insert into Info
values('Ranga','Swamy',03,34000000);
insert into Info
values('Savar','Ali',04,24000000);
insert into Info
values('Wakar','Khan',05,4566777);
insert into Info
values('Lala','Uirt',06,8900000);
Select * from Info;
select name,lastname,id,salary from Info
where salary in
(select min(salary) from Info); 
select * from Info where salary > (Select avg(salary) from Info);
select * from Info 
where id=3;
select id,salary from Info
where id=1 or id=2 or id=6;
