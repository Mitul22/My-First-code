import java.util.Scanner;
class Patt 
{
    public static void main(String args[])
    {
    Scanner obj=new Scanner(System.in);
    int n=obj.nextInt();
    int i,fact=1,sign=1,sum=0;
    for(i=1;i<=n;i++)
    {
        fact=fact*i;
        sum=sum+sign*fact;
        sign=sign*(-1);
    }
    System.out.print(sum);
 }
}