import java.util.Scanner;
class P3
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int [] arr=new int [10];
        int i,pos,j,temp=0;
        System.out.println("Enter no. of elements=>\t");
        int n=obj.nextInt();
        for(i=0;i<n;i++)
        {
            arr[i]=obj.nextInt();
        }
        System.out.println("Enter the Elements=>\t");
        for(i=0;i<n-1;i++)
        {
            pos=i;
            for(j=i+1;j<n;j++)
            {
              if(arr[pos]>arr[j])
              {
                  pos=j;
              }
              if(pos!=i)
              {
                  temp=arr[i];
                  arr[i]=arr[pos];
                  arr[pos]=temp;
              }
            }
        }
        System.out.println("sorted Array=>\t");
        for(i=0;i<n;i++)
        {
            System.out.println(arr[i]);
        }

    }
}