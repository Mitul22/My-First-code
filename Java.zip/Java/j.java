
class J
{
    int id;
    String name;
    J(int i,String n)
    {
       id=i;
       name=n;
    }
    void output()
    {
        System.out.println(id+" "+name);
    }
    public static void main(String args[])
    {
        J a=new J(12,"hello");
        a.output();
    }
}