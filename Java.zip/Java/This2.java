// now if we have a different objects calling the same method we use the same keyword this to differentiate between them in case to check which one is to be called and executed firstly
class This2 
{
    int c,d;
    void setData(int a,int b)
    {
        c=a;
        d=b;
    }
    void showData()
    {
        System.out.println("The value of A = "+c);
        System.out.println("The value of B = "+d);
    }
    public static void main(String args[])
    {
        This2 obj1=new This2();
        This2 obj2=new This2();
        obj1.setData(6,4);
        obj2.setData(4,9);
        obj1.showData();
        // obj2.showData();
    }
}