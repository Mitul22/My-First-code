import java.util.Scanner;
class Pay
{
   public static void main(String args[])
  {
   int inc,inc1;
   Scanner obj=new Scanner(System.in);
   System.out.println("Enter the salary of the employee :)");
   int sal=obj.nextInt();
   if(sal<30000)
    {
    inc=(sal*20)/100;
    sal=sal+inc;
    }
    else if(sal<20000)
    {
     inc1=(sal*10)/100;
     sal=sal+inc1;
     }
    else 
    {
     System.out.println("No increment");
     }
    System.out.println("Incremented Salaray is => "+sal);
}
}
    