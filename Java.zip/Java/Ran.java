import java.util.Scanner;
class Ran 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        System.out.print("Enter the range uptil you want prime numbers\t");
        int n=obj.nextInt();
        System.out.print("Enter the no. of prime number you want in that range=>\t");
        int m=obj.nextInt();
        int count,k=0;
        for(int i=2;i<=n;i++)
        {
            count=0;
            for(int j=2;j<i;j++)
            {
                if(i%j==0)
                count++;
            }
            if(k<m)
            {
                if(count==0)
                {
                    System.out.println(i);
                    k++;
                }
            }
        }
    }
}