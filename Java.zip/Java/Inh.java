import java.util.Scanner;
class Person
{
    Scanner obj=new Scanner(System.in);
    void dispIn()
    {
        System.out.print("Enter the name of the person=>");
        String name=obj.nextLine();
        System.out.print("Enter the age=>");
        int age=obj.nextInt();
        System.out.println("Name of person=>"+name);
        System.out.println("Age of person=>"+age);
    }
}
// class Student extends Person
// {
//     void work()
//     {
//         super.dispIn();   //super keyword can be accessed by using it in the method
//     }
// }
// class Inh
// {
//     public static void main(String args[])
//     {
//         Student o=new Student();
//         o.dispIn();
//     }
// }
class Student extends Person
{
   int id=10;
   void dispIn()
   {
       System.out.println(id);
       super.dispIn();
   }
}
class Inh extends Student{
    public static void main(String args[])
    {
        Inh s=new Inh();
        s.dispIn();
    }
}