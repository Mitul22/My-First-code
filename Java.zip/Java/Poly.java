class Person
{
    void display()
    {
        System.out.println("Hello this is method from super");
    }
}
class Poly extends Person
{
    void display()
    {
        System.out.println("Hello this is method from sub");
    }
    public static void main(String args[])
    {
        Person obj=new Poly();
        obj.display();// this will call the display method of child class as object is created for child class
    }
}