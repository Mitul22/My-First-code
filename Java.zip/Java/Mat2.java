import java.io.*;
import java.util.Scanner;
class Mat2 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int [][] mat1=new int [10][10];
        int [][] mat2=new int [10][10];
        int mul=0;
        System.out.print("Enter the no. of rows\t");
        int rows=obj.nextInt();
        System.out.print("Enter no. of cols\t");
        int cols=obj.nextInt();
        System.out.print("Enter the elements\t");
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                mat1[i][j]=obj.nextInt();
                mat2[i][j]=obj.nextInt();
            }
        }
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                mul=mul+mat1[i][j]*mat2[i][j];
            }
        }
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                System.out.print(mul);
            }
            System.out.println();
        }
    }
}