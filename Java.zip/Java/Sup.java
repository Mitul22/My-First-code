class Person
{
    int id=1010;
    void display()
    {
        System.out.println(id);
    }
}
class Citizen extends Person
{
    int id=20299;
    void display()
    {
        System.out.println(id);
        System.out.println(super.id);
    }
}
class Sup 
{
   public static void main(String args[])
   {
       Citizen obj=new Citizen();
       obj.display();
   }
}

