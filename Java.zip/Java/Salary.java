import java.util.Scanner;
class Salary
{
    public static void main(String args[])
    {
       
        Scanner obj=new Scanner(System.in);
        System.out.println("Enter the salary=>\t");
        int sal=obj.nextInt();
        if(sal>=100000)
        {
            int inc=(sal*10)/100;
            sal=sal+inc;
            System.out.println("Congratulations!!!\n");
        }
        else if(sal<=10000)
        {
            int incr=(sal*5)/100;
            sal=sal+incr;
            System.out.println("Congratulations!!!!\n");
        }
        else
        {
            int inc1=(sal*2)/100;
            sal=sal+inc1;
            System.out.println("Congratulations!!!\n");
        }
        System.out.println("Salary Incremented is=>\t"+sal);
    }
}