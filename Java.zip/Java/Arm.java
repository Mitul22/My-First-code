import java.util.Scanner;
import java.lang.Math;
class Arm 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int n=obj.nextInt();
        int count=0,rem=0,arm=0;
        int num;
        num=n;
        while(num!=0)
        {
            count++;
            num=num/10;
        }
        System.out.println(count);
        while(num>0)
        {
            rem=num%10;
            arm+=(int)((Math.pow(rem,count)));
        }
        // System.out.println(arm+" "+rem+" "+count+" "+num+" "+n);
        if(arm==num)
       {
        System.out.println("Armstrong");
       }
        else
        System.out.println("not Armstrong");
        // System.out.println("not Armstrong");
    }
}