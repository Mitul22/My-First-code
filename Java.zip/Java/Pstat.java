class Pstat 
{
    int id;
    String name;
    static String branch="Cloud Computing";
    static String newbranch()
    {
        String branch="Data Visualisation";
        return branch;
    }
    Pstat(int i,String b)
    {
        id=i;
        name=b;
    }
    public static void main(String args[])
    {
        Pstat obj=new Pstat(1010,"Ram");
        System.out.println(obj.id+" "+obj.name+" "+obj.newbranch());
    }
}
//we can access the function either by using a new keyword for meethod or we can access it byt object created by the concstructor by returnung the value from methos to main class
// and printing the required output: