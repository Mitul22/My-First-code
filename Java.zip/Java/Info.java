class Student
{
  int id;
  String name;
}
class Info
{
  public static void main(String args[])
  {
     Student S1 = new Student();
     S1.id=1010;
     S1.name="Mitul";
     Student S2 = new Student();
     S2.id=1980;
     S2.name="HELLLO";
     Student S3 = new Student();
     S3.id=2456;
     S3.name="BYEEE";
     System.out.println(S1.id +" "+S1.name+"\n"+S2.id +" "+S2.name+"\n"+S3.id +" "+S3.name);
  }
}