import java.util.Scanner;
class Print
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int N=obj.nextInt();
        int s=0,sum=0,fact=1;
        // for(int i=1;i<=N;i++)
        // {
        //     if(i%2==0)
        //     {
        //         s=s+i;
        //     }
        // } 
        // System.out.println(s);
        // int term=0;
        // for(int i=1;i<=N;i++)
        // {
        //     term=term+2;
        //     sum=sum+term;
        // }
        // System.out.println(sum);
        int c=2;
        for(int i=1;i<=N;i++)
        {
               fact=fact*i;
            //    sum=sum+fact;
            sum=sum+(c/fact);
        }
        // System.out.print(sum);
        int x=2;
        for(int i=1;i<=N;i++)
        {
              sum=sum+x*i;
        }
        System.out.print(sum);
    }
}
//x^1/1!+x2/2!+..
//