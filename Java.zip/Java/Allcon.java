import java.util.Scanner;
class Person
{
    String series="The Forgotten Army";
    void Person(String series)
    {
        this.series=series;
        System.out.println(series);
    }
}
class Citizen extends Person
{
     void Citizen()
     {
        super.Person(series);
     }
}
class Allcon
{
    public static void main(String args[])
    {
        Citizen obj=new Citizen();
        obj.Citizen();
    }
}