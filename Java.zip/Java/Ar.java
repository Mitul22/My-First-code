import java.util.Scanner;
class Ar 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int [] a =new int [5];
        for(int i=0;i<a.length;i++)
        {
            a[i]=obj.nextInt();
        }
        // for(int i=0;i<a.length;i++)
        // {
        //     System.out.println(a[i]);
        // }
        for(int i:a)
        {
            System.out.println(i);
        }

    }
}