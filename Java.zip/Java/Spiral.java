import java.util.Scanner;
class Spiral
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int m=obj.nextInt();
        int n=obj.nextInt();
        int mat[][]=new int[m][n];
        int i,j;
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                mat[i][j]=obj.nextInt();
            }
        }
        int k=0,l=0;
        while(k<m&&l<n)
        {
            for(i=l;i<n;i++)
            {
                System.out.print(mat[k][i]+" ");
            }
            k++;
            for(i=k;i<m;i++)
            {
                System.out.print(mat[i][n-1]+" ");
            }
            n--;
            if(k<m)
            {
                for(i=n-1;i>=0;i--)
                {
                    System.out.print(mat[m-1][i]+" ");
                }
                m--;
            }
            if(l<n)
            {
                for(i=m-1;i>=k;i--)
            {
                System.out.print(mat[i][l]+" ");
            }
            l++;
            }
        }
    }
}