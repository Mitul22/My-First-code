import java.util.Scanner;
class P2
{
    public static void main(String args[])
    {
        int [] arr=new int [10];
        int i,j,temp=0;
        Scanner input=new Scanner(System.in);
        System.out.println("Enter no. of elements you wanted to enter=>\t");
        int n=input.nextInt();
        System.out.println("Enter the elements=>\t");
        for(i=0;i<n;i++)
        {
            arr[i]=input.nextInt();
        }
        for(i=0;i<n-1;i++)
        {
            for(j=0;j<n-i-1;j++)
            {
                if(arr[j]>arr[j+1])
                {
                    temp=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=temp;
                }
            }
        }
        System.out.println("Elements of array are=>\t");
        for(i=0;i<n;i++)
        {
            System.out.println(arr[i]);
        }
    }
}