import java.util.*;
 
//class to print message
class ShowMessage
{
    public void dispMsg()
    {
        System.out.println("Code Quotient - Get better at coding"); 
    }
}
 
//public class
public class Msg
{
    //main method
    public static void main(String []s)
    {
        //create object of ShowMessage class.
        ShowMessage obj = new ShowMessage();
        obj.dispMsg();
    }
}