import java.lang.*;
class Math{
    public static void main(String args[])
    {
        System.out.println("Math operations in Java");
        int x=-4;
        System.out.println(Math.sqrt(x));
    }
}