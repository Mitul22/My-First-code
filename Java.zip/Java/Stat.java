class Stat 
{
    int id;  //id,name and count college are instance variables
    int age;
    String name;
    int count=0;
    static String college = "Chitkara University";
    static String  info()
    {
        String college="IIT";
        return college;
    }
    Stat(int i,int a,String n,int c)
    {
        id=i;
        age=a;
        name=n;
       // count=c;
        //count++;
    }
    
    public static void main(String args[])
    {
        //Stat.info()="IIT";
        Stat obj=new Stat(12,19,"Rohan",0);
        Stat  obj2=new Stat(13,18,"Virat",0);
        Stat obj3=new Stat(14,20,"Shrey",0);
        System.out.println(obj.id+" "+obj.age+" "+obj.name+obj.info()+obj.count);
        System.out.println(obj2.id+" "+obj2.age+" "+obj2.name+obj.college+obj2.count);
        System.out.println(obj3.id+" "+obj3.age+" "+obj3.name+obj.college+obj.count);
    }

}