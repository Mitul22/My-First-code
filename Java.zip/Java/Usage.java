package pac2;
import pack.*;
class Usage
{
    public static void main(String args[])
    {
        Person obj=new Person();
        obj.show();
    }
}