class Copy
{
    Copy(int x,int y)
    {
        return (x+y);
    }
    Copy()
    {
        Copy{
        x=10;
        y=20;
        }
    }
    public static void main(String args[])
    {
        Copy obj=new Copy();
        System.out.print(obj.Copy(10,20));
    }
}