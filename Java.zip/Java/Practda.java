import java.util.Scanner;
class Practda
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        System.out.print("Enter a number\t");
        int x=obj.nextInt();
        System.out.print("Enter another number\t");
        int y=obj.nextInt();  
        System.out.print("Enter a floating point\t");
        float z=obj.nextFloat();
        System.out.println("Addition of x and y => "+(x+y));
        System.out.println("Subtraction of and y => "+(x-y));
        System.out.println("Multiplication of x and y => "+(x*y));
        System.out.println("Modulus of x and y => "+(x%y));
        System.out.println("Maximum of x and y is => "+Math.max(x,y));
        System.out.println("Minimum of x and y is => "+Math.min(x,y));
        System.out.println("Square root of x and y => "+Math.sqrt(x)+" "+Math.sqrt(y));
       // System.out.println("Ciel of z is "+Math.ciel(z));
        System.out.println("Floor of z is => "+Math.floor(z));

    }
}