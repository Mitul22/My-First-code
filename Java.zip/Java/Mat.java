import java.io.*;
import java.util.Scanner;
class Mat 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int [][] mat=new int [3][3];
        for(int i=0;i<mat.length;i++)
        {
            for(int j=0;j<mat.length;j++)
            {
                mat[i][j]=obj.nextInt();
            }
        }
        for(int i=0;i<mat.length;i++)
        {
            for(int j=0;j<mat.length;j++)
            {
                System.out.print(mat[i][j]);
            }
            System.out.println();
        }
    }
}