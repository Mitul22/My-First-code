import java.util.Scanner;
class Mat6 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int mat [][]=new int [10][10];
        System.out.print("Enter no. of rows\t");
        int rows=obj.nextInt();
        System.out.print("Enter no. of cols\t");
        int cols=obj.nextInt();
        System.out.println("Enter no. of elements==");
        int isUpper=1;
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                mat[i][j]=obj.nextInt();
                if(cols<rows&&mat[i][j]!=0)
                {
                    isUpper=0;
                }
            }
        }
        if(isUpper==1)
        {
            for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                System.out.print(mat[i][j]+" ");
            }
            System.out.println();
        }
        }
        else
        {
            System.out.println("Not upper traingle");
        }
    }
}