import java.util.Scanner;
class Loop
{
  public static void main(String args[])
  {
   int rem=0,rev=0;
   Scanner obj=new Scanner(System.in);
   System.out.println("Enter a number=>\t");
   int n=obj.nextInt();
   System.out.println("-------------------\nReverse of a number in Java:)");
   while(n!=0)
   {
     rem=n%10;
     rev=rev*10+rem;
     n=n/10;
   }
   System.out.println(rev);
}
}
   