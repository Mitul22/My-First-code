import java.util.Scanner;
class Person
{
    String name="Ram Murthy";
    int age=45;
}
class Student extends Person
{
      int id=1010;
    void display()
    {
        System.out.println("Student id is "+id);
    }
}
class Citizen extends Student
{
    String series="The Forgotten Army";
    void show()
    {
        System.out.println(series);
    }
}
class Multinh
{
   public static void main(String args[])
   {
    Citizen obj=new Citizen();
    obj.display();
    obj.show();
   }
}