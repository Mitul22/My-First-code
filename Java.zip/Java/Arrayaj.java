import java.util.Scanner;
class Arrayaj
{
	public static void main(String args[])
	{
		int arr[]=new int[10];
		Scanner obj=new Scanner(System.in);
		System.out.println("Enter no. of elements=>\t");
		int n=obj.nextInt();
		int sum=0;
		System.out.println("Enter the elements=>\t");
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=obj.nextInt();
		}
		System.out.println("Sum of array elements=>\t");
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		System.out.print("Sum of array elements is "+sum);
		
	}
}