import java.util.Scanner;
class Sup
{
    int id;
    Sup(int id)
    {
        this.id=id;   //this keyword is used to differntiate between instance and parameter variables
        System.out.println("This is id of Super class"+id);
    }
}
class Sub extends Sup
{
    Sub(int id,int pid)
    {
        super(id);
        System.out.println("This is id of Sub class"+pid);
    }
}
class Csup
{
    public static void main(String args[])
    {
        Sub obj=new Sub(100,200);
    }
}