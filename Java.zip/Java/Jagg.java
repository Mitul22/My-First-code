
import java.util.Scanner;
class Jagg 
{
    public static void main(String args[])
    {
        int mat[][]=new int [3][];
        int count=0;
        for(int i=0;i<mat.length;i++)
        {
            for(int j=0;j<mat[i].length;j++)
            {
                mat[i][j]=count++;
            }
        }
        for(int i=0;i<mat.length;i++)
        {
            for(int j=0;j<mat[i].length;j++)
            {
                System.out.print(mat[i][j]);
            }
            System.out.println();
        }
    }
}