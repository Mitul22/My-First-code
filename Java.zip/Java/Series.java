import java.util.Scanner;
class Series 
{
    public static void main(String args[])
    {
        int i,n,sign=1,sum=0,x=2,p=1;
        Scanner obj=new Scanner(System.in);
        n=obj.nextInt();
        for(i=1;i<=n;i++)
        {
            p=p*x;
            sum=sum+p*sign;
            sign=sign*-1;
        }
        System.out.print(sum);
    }
}