import java.util.Scanner;
class Person
{
    String  name="Hello this is MXPlayer";
    void Person()      //we are using constructor in this class
    {
        System.out.println(name.length());
    }
}
class Citizen extends Person
{
    String name="This is Amazon Prime";
    void Citizen()   // we have used constructor for displaying the output of the superclass
    {
        System.out.println(super.name);   //super key only access the variables present in the parent class
        super.Person();
    }
}
class Conall
{
    public static void main(String args[])
    {
        Citizen obj=new Citizen();
        obj.Citizen();
    }
}
