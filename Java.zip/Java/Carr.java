import java.util.Scanner;
class Carr
{
    public static void main(String args[])
    {
        //  Scanner obj=new Scanner(System.in);
        //  int a[]=new int[10];
        //  int b[]=new int[10];
        // int j;
        // //=b.length;
        //  for(int i=0;i<a.length;i++)
        //  {
        //      a[i]=obj.nextInt();
        //  }
        //  for(int i=0;i<a.length;i++)
        //  {
        //     b[i]=a[a.length-i-1];
        //  }
        //  for(int i=0;i<b.length;i++)
        //  {
        //     System.out.println(b[i]);
        //  }
        int[][] arr = {{1,2,3}, {4,5}, {1,5,9}};
        for(int[] i:arr)
        {
            for(int j:i)
                System.out.print(j+" ");
            System.out.println();
        }
    }
}