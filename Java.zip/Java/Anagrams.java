import java.util.Scanner;
class Anagrams
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        String str;
        String s;
        int flag=0;
        int n=obj.nextInt();
        for(int i=0;i<n;i++)
        {
            str=obj.nextLine();
            s=obj.nextLine();
        }
        if(str.length()==s.length())
        {
              for(int i=0;i<str.length();i++)
              {
                  if(str.equals(s))
                  flag=1;
              }
        }
        else
        {
            System.out.println("Not Anagrams");
        }
         if(flag==1)
         {
             System.out.println("Anagrams");
         }
         else{
             System.out.println("Not Anagrams");
         }
    }
}