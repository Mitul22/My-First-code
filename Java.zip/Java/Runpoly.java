import java.util.Scanner;
class Par
{
    int l;
    int b;
    int h;
    void area(int b,int l,int h)
    {
        this.b=b;
        this.l=l;
        this.h=h;
        System.out.println("the area of room "+(l*b+b*h+h*l));
        System.out.println("the area from parent class");
    }
}
class Sup extends Par
{
    int h;
    void area(int b,int l,int h)
    {
        this.h=h;
        System.out.print("area of room "+(l*b+b*h+h*l));
    }
}
class Runpoly extends Sup
{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the length=>\t");
        int len=sc.nextInt();
        System.out.println("Enter the breadth=>\t");
        int bre=sc.nextInt();
        System.out.println("Enter the height=>\t");
        int hei=sc.nextInt();
        Par obj=new Sup();
        obj.area(len,bre,hei);
    }
}