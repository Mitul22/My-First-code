import java.util.Scanner;
class Data
{
   public static void main(String args[])
   {
     String name,exp;
     int Salary;
     Scanner obj=new Scanner(System.in);
     System.out.println("Enter the employee ID");
     int id=obj.nextInt();
     switch(id)
     {
      case 1:
     { name="Ram Murthy";
      Salary=32220004;
      exp="3 yrs";
      break;
      }
       case 2:
      {
      name="Suresh Kumar";
      Salary=200004;
      exp="3 yrs";
      break;
      }
       case 3:
      {
      name="Laxmi Gujral";
      Salary=22200000;
      exp="3 yrs";
      break;
      }
       case 4:
      {
      name="Sita Sharma";
      Salary=3550004;
      exp="3 yrs";
      break;
      }
       case 5:
      {
      name="Eleshwar";
      Salary=6400000;
      exp="3 yrs";
      break;
      }
       case 6:
      {
      name="Tapur Basu";
      Salary=844000004;
      exp="3 yrs";
      break;
      }
       default:
      {
      name="Invalid";
      Salary=0;
      exp="NULL";
      break;
      }
     }
     System.out.println(name+"\n"+"\n"+Salary+"\n"+exp);
   }
}