abstract class Per
{
    public abstract void disp();
   public void show()
   {
       System.out.println("This is from abstract classs");
   }
}
class Abstr extends Per
{
   public void disp()
    {
        System.out.println("This is from extended class");
    }
    public static void main(String args[])
    {
        // Abstr obj=new Abstr();
        Per obj=new Abstr();
        obj.disp();
        obj.show();
    }
}