import java.util.Scanner;
//import java.lang.Array;
class P5
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int [] arr=new int[10];
        System.out.println("Enter number of elements=>\t");
        int n=obj.nextInt();
        int i,j,temp=0;
        for(i=0;i<n;i++)
        {
            arr[i]=obj.nextInt();
        }
        for(i=0;i<n;i++)
        {
            temp=arr[i];
            j=i-1;
            while(temp<arr[j]&&j>=0)
            {
              arr[j]=arr[j+1];
              j--;
            }
            arr[j-1]=arr[j];
        }
        System.out.println("Sorted Array=>\t");
        for(i=0;i<n;i++)
        {
            System.out.print(arr[i]+" ");
        }
    }
}