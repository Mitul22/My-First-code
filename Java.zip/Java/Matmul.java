import java.util.Scanner;
class Matmul
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int t=obj.nextInt();
        for(int p=0;p<t;p++)
        {
            int r=obj.nextInt();
            int c=obj.nextInt();
            int mat1[][]=new int [r][c];
            int mul[][]=new int[10][10];
            for(int i=0;i<r;i++)
            {
                for(int j=0;j<c;j++)
                {
                  mat1[i][j]=obj.nextInt();   
                }
            }
            int m=obj.nextInt();
            int n=obj.nextInt();
            int mat2[][]=new int [m][n];
            for(int i=0;i<m;i++)
            {
                for(int j=0;j<n;j++)
                {
                  mat2[i][j]=obj.nextInt();   
                }
            }
            if(c!=m)
            {
                System.out.print("Multiplication is not possible");
            }
            else{
                for(int i=0;i<r;i++)
                {
                    for(int j=0;j<n;j++)
                    {
                        for(int k=0;k<m;k++)
                        {
                            mul[i][j]+=mat1[i][k]*mat2[k][j];
                        }
                    }
                }
            }
            for(int i=0;i<r;i++)
            {
                for(int j=0;j<n;j++)
                {
                    System.out.print(mul[i][j]+" ");
                }
                System.out.println();
            }
        }
    }
}