class Employee
{
  int id;
  int age;
  String name;
  int salary;
   public static void main(String args[])
  {
   Employee E1 = new Employee();
   Employee E2 = new Employee();
   Employee E3 = new Employee();
   E1.id=1010;
   E1.age=30;
   E1.name="Ram Swamy";
   E1.salary=2300000;
   E2.id=2389;
   E2.age=34;
   E2.name="Kilva Kumar";
   E2.salary=120000;
   E3.id=1867;
   E3.name="Suma Murthy";
   E3.age=23;
   E3.salary=3455500;
   System.out.println(E1.id+" "+E1.age+" "+E1.name+" "+E1.salary+"\n"+E2.id+" "+E2.age+" "+E2.name+" "+E2.salary+"\n"+E3.id+" "+E3.age+" "+E3.name+" "+E3.salary);
   }
}
   
  
  