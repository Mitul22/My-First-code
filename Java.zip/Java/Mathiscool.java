import java.lang.*;
class Mathiscool{
    public static void main(String args[])
    {
        System.out.println("Math operations in Java");
        int x=-4;
        System.out.println(Math.class);
    }
}