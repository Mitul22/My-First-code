import java.util.Scanner;
class Attend
{  
  public static void main(String args[])
  {
  Scanner obj1=new Scanner(System.in);
  Scanner obj2=new Scanner(System.in);
  System.out.println("Input no. of lectures deleivered\t");
  double cdel=obj1.nextInt();
  System.out.println("Input no. of lectures attended\t");
  double catt=obj2.nextInt();
  double per=(catt/cdel)*100;
  System.out.println(per);
  if(per>=70) 
  {
   System.out.println("Student is allowed to sit in the exam:)"); 
  }
  else 
  {
  System.out.println("Student is not allowed to sit in the exam"); 
  }
  }
}