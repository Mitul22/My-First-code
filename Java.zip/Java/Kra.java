import java.util.Scanner;
class Kra
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
         int n=obj.nextInt();
         int rem=0,rev=0,i;
         for(i=0;i<n;i++)
         {
             int num=obj.nextInt();
             int on=num;
             while(num>0)
             {
                 rem=num%10;
                 rev=rev*10+rem;
                 num=num/10;
             }
             if(rev==on)
             System.out.println("Equal");
             else
             System.out.println("Not Equal");
             rev=0;
         }
    }
}