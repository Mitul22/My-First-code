import java.util.Scanner;
class Grades
{
  public static void main(String args[])
   {  
    Scanner obj=new Scanner(System.in);
    System.out.println("Enter a mark");
    int marks=obj.nextInt();
    switch(marks)
    {
     case 90:
     System.out.println("A+");
     break;
     case 70:
     System.out.println("A+");
     break;
     case 50:
     System.out.println("A+");
     break;
     case 30:
     System.out.println("A+");
     break;
     default:
     System.out.println("Sorry");
     break;
       }
}
}