import java.util.Scanner;
interface Person
{
    public void disp(String n,int id,int sal);
}
interface Citizen
{
    public  void show(int sal);
}
class Inf implements Person,Citizen
{
    public void disp(String n,int id,int sal)
    {
        System.out.println("NAME "+n+"\n"+"SALARY "+sal+"\n"+"ID "+id);
    }
    public void show(int sal)
    {
        int inc=0;
        if(sal>=20000)
        {
            inc=(sal)/100;
            sal=sal+inc;
            System.out.println("Congratulations you got PROMOTION ");
        }
        else if(sal>=40000)
        {
            inc=(sal)/500;
            sal=sal+inc;
            System.out.println("Congratulations you got PROMOTION ! ");
        }
        else if(sal>=80000)
        {
            inc=(sal*40)/100;
            sal=sal+inc;
            System.out.println("Congratulations you got PROMOTION ! ");
        }
        else 
        {
            System.out.println("Sorry !!! you didn't get promotion");
        }

    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the name of the employee");
        String n=sc.nextLine();
        System.out.println("Enter the id of the employee");
        int id=sc.nextInt();
        System.out.println("Enter the salary of the employee");
        int sal=sc.nextInt();
        Inf obj=new Inf();
        obj.disp(n,id,sal);
        obj.show(sal);
    }
}