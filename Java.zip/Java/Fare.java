import java.util.Scanner;
class Fare
{
public static void main(String[] args)
{
    Scanner obj=new Scanner(System.in);
     int count=0,pay=0,i;
     int c=0;
     for(i=0;i<++c;i++)
     {
       char pc=obj.next().charAt(0);
      if(pc=='p')
     {
       //payingCar();
       pay=pay+50;
      count++;
     } 
     else if(pc=='n')
     {
        pay=0;
     }
       else if(pc=='q')
         break;
     }
    c++;
     System.out.println("Total Cash : "+pay+"/-");
     System.out.println("Total Cars : "+count);

}
}