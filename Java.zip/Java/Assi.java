import java.util.Scanner;
class Task
{
    final int a=10;
    void display()
    {
        System.out.println(a);
    }
}
class Stu extends Task
{
    void display()
    {
        int a=20;
        System.out.println(a);
    }
}
class Assi
{
   public static void main(String args[])
   {
       Assi obj=new Assi();
       Task on=new Task();
       obj.display();
   }
}
