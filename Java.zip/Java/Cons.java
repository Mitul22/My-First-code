import java.util.Scanner;
class Cons
{
    int x,y;
    void input(int x,int y)
    {
            this.x=x; // this keyword
            this.y=y;  //used in this function
    }
    void swap(int a,int b)
    {
       int swp=a;
       a=b;
       b=swp;
    }
    void output()
     {
         System.out.println("The value of x="+x);
         System.out.print("The value of y="+y);
     }
     void printArray(int []arr)
     {
         for(int i=0;i<arr.length;i++)
         {
             System.out.print(" "+arr[i]+" ");
         }
     }
     void printArray(int arr[],int alen)        
     {
        int sum=0;
         for(int i=0;i<alen;i++)
         {
            //  int sum=0;
             sum=sum+arr[i];
            //  System.out.println(sum);
         }
         System.out.println(sum);
     }
    public static void main(String args[])
    {
        Cons obj=new Cons();
        Scanner input=new Scanner(System.in);
        System.out.println("Enter 1st number=\t");
        int a=input.nextInt();
        System.out.println("Enter 2nd number=\t");
        int b=input.nextInt();
        obj.input(a,b);
        obj.swap(a,b);
        obj.output();
        int arr []=new int[]{1,2,3,4,5,6};
        obj.printArray(arr);
        int len=arr.length;
        obj.printArray(arr,len);
    }

}