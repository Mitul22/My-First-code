interface Per 
{
    void disp();
}
interface Per2 
{
    void disp();
}
class Mul implements Per,Per2
{
    public void disp()
    {
      System.out.println("This is from Parent 1");
    }
    public  void disp()
    {
        System.out.println("This is from PArent 2");
    }
    public static void main(String args[])
    {
           Per obj1=new Mul();
           Per obj2=new Mul();
           obj1.disp();
           obj2.disp();
    }
}