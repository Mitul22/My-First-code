/*System.out.println(Math.abs(-5));Output is 5
        System.out.println(Math.ceil(-5));//Output is -5.0

           to get numbers between 0-100 we go as 0-(100-1)
           Floor Function in C and JAva
    
        float f=3.9;
        int x=(int)f;
        Automatic casting is moving a dataytpe variable to move it from smaller to larger container
        Absolute function returns value without a sign
          System.out.println(Math.acos(-5));Output is NaN
           in c and java if the number starts with 0 then it is a octal number
            System.out.println(0144); Output is=>4x8^0+4x8^1+1x8^2=100
           System.out.println(0x64); Output is 100 again for hexadecimal
           when there are too many digits in a number we can write underscore in the number 
           we can  write _ in the number in the middle of the number only not in the starting or ending
           System.out.println(00_000_000_000_100); Output of this number is 64!
           System.out.println(Integer.toOctalString(100)); the output is 144
           System.out.println(Integer.toHexString(100)); the output is 64
           what is parseInt?
           Integer x=new Integer("100");
           parse comes from a techincal term called parser which parses a string to seperate words of a string
         parseInt will take whatsover is present in the string
         when you parse it parse it considering it as a binary string
         import java.util.Scanner;
import java.lang.Math;
class Main
{
    public static void main(String args[])
    {
        Scanner input=new Scanner(System.in);
        int x;
        System.out.println("Enter a Binary");
        x=Integer.parseInt(input.nextLine(),2);
//        System.out.println(Integer.toHexString(100));
         System.out.println(x);
              
    }
}
the output of above code is 52 when user enters 34
import java.util.Scanner;
import java.lang.Math;
class Main
{
    public static void main(String args[])
    {
        Scanner input=new Scanner(System.in);
        int x;
        System.out.println("Enter a Hexadecimal");
        x=Integer.parseInt(input.nextLine(),16);
//        System.out.println(Integer.toHexString(100));
         System.out.println(x);
              
    }
}
   Basically nextline is a keyword in java which inputs a string it is a Math library function also we use parseInt which takes number from the string and then it is used in the calculation
   import java.util.Scanner;
import java.lang.Math;
class Main
{
    public static void main(String args[])
    {
        Scanner input=new Scanner(System.in);
        int x;
        System.out.println("Enter a Hexadecimal");
        x=Integer.parseInt(input.nextLine(),8);
//        System.out.println(Integer.toHexString(100));
         System.out.println(x);
              
    }
}
 This program will take input as octal number from the string and will perform calculations in java program
 Diff b/w value and symbol -> Symbols are used to communicate.It is used to represent value in programmming.
 */