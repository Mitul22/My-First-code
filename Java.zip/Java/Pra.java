import java.util.Scanner;
class Pra
{
    public static void main(String args[])
    {
           Scanner in=new Scanner(System.in);
           System.out.println("Enter a number=>\t");
           int n=in.nextInt();
           int fact=1,i,ft=0,st=1,nt;
           for(i=1;i<=n;i++)
           {
               fact=fact*i;
           }
           System.out.println("Factorial of number=>\t"+fact);
          System.out.println("Enter no. of terms to get printed=>\t");
          int t=in.nextInt();
          System.out.println(ft+" "+st);
          for(i=0;i<t;i++)
          {
                nt=ft+st;
               
          }
    }
}