class Empinfo
{
  double salary;
  String name;
}
class Emp1
{
  public static void main(String args[])
  {   
     double avg;
     Empinfo obj1 = new Empinfo();
     Empinfo obj2 = new Empinfo();
     obj1.salary=112000.00;
     obj1.name="Sri Murthy";
     obj2.salary=344899.00;
     obj2.name="Ram Nathan";
     System.out.println(obj1.salary+"\t"+obj1.name+"\n"+obj2.salary+"\t"+obj2.name);
     avg=(obj1.salary+obj2.salary)/2;
      System.out.println("AVERAGE of salaries => "+avg);
   }
}