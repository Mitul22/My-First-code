import java.util.Scanner;
class Person
{
    String name="Ram Murthy";
    int age=45;
    void display()
    {
        System.out.println(name+" "+age);
    }
}
class Student extends Person
{
    int id=10101;
    void display()
    {
        System.out.println(id);
    }
} 
class Inherit
{
    public static void main(String args[])
    {
       Student obj=new Student();
      obj.display();
       obj.display();   ///super keyword is used
    }
}