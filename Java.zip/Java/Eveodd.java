import java.util.Scanner;
class Eveodd
{
   public static void main(String args[])
   {
    Scanner obj=new Scanner(System.in);
    System.out.println("Input a number=>\t");
    int num=obj.nextInt();
    if(num%2==0)
    {
     System.out.println("Even number");
    }
    else
    {
     System.out.println("Odd number");
    }
    
   }
}
  