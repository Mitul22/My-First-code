import java.util.Scanner;
// Other imports go here
// Do NOT change the class name
class Main{
    public static void main(String[] args)
    {
         Scanner obj=new Scanner(System.in);
          int p=obj.nextInt();
          int r=obj.nextInt();
          int t=obj.nextInt();
       
//           float amount=(float)(p*Math.pow((r/2+1),t));
        float CI = (float)(102.5+p* (Math.pow((1 + r / 100), t)));
          System.out.print(CI);
    }
}