import java.util.Scanner;
interface Person
{
    public void disp(String n,int id,int s);
}
class Interf implements Person
{
    public void disp(String n,int id,int s)
    {
        System.out.println("Name of the person"+n);
        System.out.println("Id of the person "+id);
        System.out.println("Salary of the person "+s);
    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the name of the person\t");
        String n=sc.nextLine();
        System.out.println("Enter the id of the person\t");
        int id=sc.nextInt();
        System.out.println("Enter the salary of the person\t");
        int salary=sc.nextInt();
        Interf obj=new Interf();
        obj.disp(n,id,salary);
    }
}