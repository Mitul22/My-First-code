// package pack;
// public class Citizen
// {
//     public void msg()
//     {
//         System.out.println("This is my first package!");
//     }
// }
package pack2;
import pack.*;
class Person
{
    public static void main(String args[])
    {
        Citizen obj=new Citizen();
        obj.msg();
    }
}
