class Person
{
      String name="Chinappa";
      void display()
      {
          System.out.println(name);
      }
}
class Mover extends Person
{
    String series="The Forgotten Army";
    void display()
    {
        System.out.println(series);
    }
    public static void main(String args[])
    {
        Mover obj=new Mover();
        obj.display();
    }
}