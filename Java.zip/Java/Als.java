class Sup
{
    Sup()
    {
        System.out.print("This is printed from super class:)");
    }
}
class Cit extends Sup
{
   Cit()
    {
        super();
    }
}
class Als
{
    public static void main(String args[])
    {
        Cit obj=new Cit();   // when dont need to call it again through object created by its class
    }
}