import java.util.Scanner;
class Addrem 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int n=obj.nextInt();
        int m=0,rem=0;
        int num=n;
        while(num>0)
        {
            rem=num%10;
            rem++;
            m=m*10+rem;
            num=num/10;
        }
        System.out.print(m);
    }
}