import java.util.Scanner;
class Kaprekar
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int t=obj.nextInt();
        for(int i=0;i<t;i++)
        {
            int n=obj.nextInt();
            int cn=n;
            int sq=n*n;
            int rem=0,sum=0,count=0;
            while(n>0)
            {
                count++;
                n=n/10;
            }
            while(sq>0)
            {
                rem=(int)(sq%Math.pow(10,count));
                sum=sum+rem;
                sq/=Math.pow(10,count);
            }
            // System.out.print(cn+" "+sum);
            if(sum==cn)
            System.out.println(1);
            else
            System.out.println(0);
        }
    }
}