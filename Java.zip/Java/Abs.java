import java.util.Scanner;
abstract class Parent 
{
   public  abstract void disp(String x,int y,int n);
}
class Abs extends Parent
{
    public void disp(String x,int y,int n)
    {
        System.out.println("Name of the Employee "+x);
        System.out.println("Salary of the employee "+y);
        System.out.println("Id of the employee "+n);
    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the name of the person");
        String name=sc.nextLine();
        System.out.println("Enter id");
        int a=sc.nextInt();
        System.out.println("Enter salary");
        int b=sc.nextInt();
        Abs obj=new Abs();
        obj.disp(name,a,b);
    }
}