//this is the keyword used as a object in defining which helps to find difference between the instance variables and the local variables if the variables have same names
// this keyword is also used in the case when we use two objects and the compiler is confused between the objects in order to calculaye whether which object method to execute first
import java.util.Scanner;
class This 
{
    int a,b;
    void setData(int a,int b)
    {
        this.a=a; //Now as we have used this keyword as object in the variable so it will
        this.b=b; // not confuse and will consider instance variables differently.
    }
    void showData()
    {
        System.out.println("Value of  A= "+a);
        System.out.println("Value of  B= "+b);
    }
    public static void main(String args[])
    {
        This obj=new This();
        obj.setData(3,4);
        obj.showData();
    }
    // if we dont use this keyword in the above program,we get the values of A=0,B=0 but if we use this keyword we get a different output.
}