package packs2;
import packs.Benz;
public class Pheno implements Aromatic
{
    public static void main(String args[])
    {
        System.out.println("This is class of one of the packages of JAVA created by the user.");
    }
    public void disp()
    {
        System.out.println("This is interface from a user defined package!!!");
    }
}
interface Aromatic
{
   public void disp();
}
