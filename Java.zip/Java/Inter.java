interface Per 
{
      void disp();
}
class Inter implements Per
{
    public void disp()
    {
        System.out.println("This is a method of Interface");
    }
    public static void main(String args[])
    {
        Per obj=new Inter();
        obj.disp();
    }
}