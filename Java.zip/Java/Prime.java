import java.util.Scanner;
class Prime 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        System.out.print("Enter a number=>\t");
        int p=obj.nextInt();
        int count=0;
        for(int i=2;i<=10;i++)
        {
            if(p%i==0)
            count++;
        }
        if(count==1)
        System.out.println("Prime number");
        else
        System.out.println("Not Prime number");

    }
}