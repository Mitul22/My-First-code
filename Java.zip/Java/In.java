class In
{
    int id;
    static String college="Chitkara University";
    static void change()
    {
        String college="IIT";
    } 
    In(int i)
    {
        id=i;
      //  college=c;
    }
    public Static void main(String args[])
    {
        In obj=new In(10);
        System.out.print(obj.id+" "+obj.change());
    }
}