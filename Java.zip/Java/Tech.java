import java.util.Scanner;
class Tech
{
    public static void main(String args[])
    {
    //    Scanner obj=new Scanner(System.in);
    //    System.out.println("Enter a number");
    //    int num=obj.nextInt();
       //System.out.println(num);
        // Scanner obj=new Scanner(System.in);
          
        //  System.out.println("Enter a Binary->");
        //  int num=Integer.parseInt(obj.nextLine(),2);// parse will extract number from the string
        // System.out.println(Integer.toHexString(10)); Output is a
        //  System.out.println(Integer.toOctalString(100));//Output is 144
        //  System.out.println(Integer.toHexString(100));  //Output is 64
        // Scanner obj=new Scanner(System.in);
        // System.out.println("Enter a character\t");
        // char chara=obj.next().charAt(0);
        // if(chara>='a'&&chara<='z')
        // {
        //     chara=(char)(chara-32);
        // }
        // else
        // {
        //     chara=(char)(chara+32);
        // }
        // System.out.println("character converted=>\t"+chara);
        // String [] mobileno=new String[10];
         //int x=4;
        // mobileno[1]="23333333566";
        // mobileno[3]="42444235696";
        // mobileno[5]="00033333566";
        // mobileno[7]="111133435566";
       // System.out.println(mobileno[--x]);//the index whose value is neither inputed by the user nor assigned initially has null value!!!
        // int [] arr=new int[60];
        // arr[0]=2;
        // arr[1]=3;
        // arr[2]=45;
        // arr[3]=34;
        // arr[4]=56;
        // System.out.println(arr[x-2]);//negative indexes of array gives a warning of array index out of bounds exception
        Scanner input=new Scanner(System.in);
        int n,i,sum=0;
        System.out.println("Input no. of elements of array=>\t");
        n=input.nextInt();
        int [] arr=new int[n];
        System.out.println("Enter the elements=>\t");
        for(i=0;i<n;i++)
        {
            arr[i]=input.nextInt();
            sum=sum+arr[i];
        }
        System.out.println("Sum of array of numbers is => "+sum);
    }
}
