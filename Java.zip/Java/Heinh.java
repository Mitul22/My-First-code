import java.util.Scanner;
class Person
{
    String name="Ram Murthy";
    int age=34;
}
class Student extends Person{
    int id=1010;
    void display()
    {
        System.out.println("Student id is "+id);
    }
}
class Citizen extends Student{
    String series="The Forgotten Army";
    void display()
    {
        System.out.println(series);
    }
}
class Heinh
{
    public static void main(String args[])
    {
        Citizen obj1=new Citizen();
        Student obj2=new Student();
        obj1.display();
        obj2.display();
    }
}