class Para 
{
    int a,b,res;
    Para(int x,int y)
    {
        System.out.println("==Hello this is parameterized constructor==");
        a=x;
        b=y;
        res=a*b;
        System.out.print(res);
    }
    public static void main(String args[])
    {
        Para obj=new Para(10,90);
         System.out.print(obj);
    }
}
