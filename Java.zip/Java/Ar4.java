import java.io.*;
class Ar4 
{
    int function()
    {
        return new int [] {1,2,3,4,5};
    }
    public static void main(String args[])
    {
        Ar3 obj=new Ar3();
        int arr[]=obj.function();
        for(int i=0;i<arr.length;i++)
        {
            System.out.println(arr[i]);
        }
    }
}