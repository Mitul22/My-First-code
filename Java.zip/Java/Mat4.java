import java.io.*;
import java.util.Scanner;
class Mat4
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int [][] mat1=new int [10][10];
        int [][] mat2=new int [10][10];
        int [][] add=new int [10][10];
        System.out.print("Enter no. of rows\t");
        int rows=obj.nextInt();
        System.out.print("Enter no. of cols\t");
        int cols=obj.nextInt();
        System.out.print("Enter no. of elements\t");
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                mat1[i][j]=obj.nextInt();
                mat2[i][j]=obj.nextInt();
            }
        }
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                add[i][j]=mat1[i][j]+mat2[i][j];
                System.out.print(add[i][j]+" ");
            }
            System.out.println();
        }
    
    }
}