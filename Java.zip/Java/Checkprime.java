import java.util.Scanner;
class Checkprime
{
     static int check(int n)
     {
         int flag=0;
         for(int i=0;i<n/2;i++)
         {
             if(n%i==0)
             flag=1;
         }
         if(flag==1)
         return 1;
         else
         return 0;
     }
     public static void main(String args[])
     {
       //  Checkprime obj=new Checkprime();
          Scanner ob=new Scanner(System.in);
          int n=ob.nextInt();
          int val=check(n);
          System.out.println(val);

     }
}