import java.util.Scanner;
class jv
{
  public static void main(String args[])
  {
  int num;
  System.out.println("Enter a number");
  Scanner obj = new Scanner(System.in);
  num = obj.nextInt();
  System.out.println("Square of number "+num*num);
  }
}