class Arrr
{
    public static void main(String args[])
    {
        int [] arr=new int[] {1,2,3,4,5};
        int i,s=0,j;
        for(i=0;i<arr.length;i++)
        {
            s=s+arr[i];
        }
        System.out.println("Sum of 1+2+3+4+5=>"+s);
       // System.out.print("1\n"+"2\n"+"3\n"+"4\n"+"5\n");
        for(i=1;i<=5;i++)
        {
            System.out.println(i);
        }
        for(i=0;i<=3;i++)
        {
            for(j=1;j<=i;j++)
            {
                System.out.print(i+j);
            }
            System.out.println();
        }
    }
}