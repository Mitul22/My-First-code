class Sup
{
    int id;
    Sup(int id)
    {
        this.id=id;
        System.out.print("The id of Superclass is \t"+id);
    }
}
class Sub extends Sup
{
    int i;
    Sub(int id,int pid)
    {
         super(id);
         i=pid;
         System.out.print("The id of subclass is \t"+i);
    }
}
class Alss
{
    public static void main(String args[])
    {
        Sub obj=new Sub(1010,2367);

    }
}