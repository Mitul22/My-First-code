import java.util.Scanner;
class Arr
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int n,i;
        int [] arr=new int[40];
        System.out.println("Enter no. of elements of array=>\t");
        n=obj.nextInt();
        System.out.println("Enter the elements=>\t");
        for(i=0;i<n;i++)
        {
            arr[i]=obj.nextInt();
        }
        System.out.println("Even  Elements of array=>");
        for(i=0;i<n;i++)
        {
            if(arr[i]%2==0)
            {
              System.out.println(arr[i]);
            }
        }
        System.out.println("Odd Elements of array=>\t");
        for(i=0;i<n;i++)
        {
            if(arr[i]%2!=0)
            {
                System.out.println(arr[i]);
            }
        }

    }
}