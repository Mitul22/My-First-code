import java.util.Scanner;
class Person
{
    String name="Ram";
    void Msg()
    {
        System.out.println(name);
    }
}
class Citizen extends Person
{
    String series="The Forgotten Army";
    void disp()
    {
        System.out.println(series); //this is method overrriding as the same method is called in Parent class

    }
    void work()
    {
        super.Msg();//super keyword is used to access the instance variables and methods of the parent class 
                    //we can call the fucntion just by creating a method in the child class and then calling the parent class method in that method using the super keyword 
    }
}
class Super extends Citizen
{
    public static void main(String args[])
    {
        Super obj=new Super();
        obj.disp();
        obj.work();
    }
}