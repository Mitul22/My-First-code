import java.util.Scanner;
class Fa
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int n=obj.nextInt();
        int an=n;
        int num=n;
        int sum=0;
        int rev=0,rem=0;
        int arm=0;
        int count=0,sq=n*n;
        // while(num>0)
        // {
        //     rem=num%10;
        //     rev=rev*10+rem;
        //     num=num/10;
        // }
        // System.out.print("Reverse of number is "+rev);
        //sum of digits
        // while(num>0)
        // {
        //     rem=num%10;
        //     sum=sum+rem;
        //     num=num/10;
        // }
        // System.out.print("Sum of digits of number "+sum);
        //Armstrong number
        // while(num>0)
        // {
        //     rem=num%10;
        //     arm=arm+rem*rem*rem;
        //     num=num/10;
        // }
        // if(arm==n)
        // System.out.print("Armstrong number");
        // else
        // System.out.print("Not Armstsrong number");
        //Armstrong number for n number of digits
    //     while(num>0)
    //     {
    //         num=num/10;
    //         count++;
    //     }
    //     while(n>0)
    //     {
    //         rem=n%10;
    //         arm+=(int)(Math.pow(rem,count));
    //         n=n/10;
    //     }
    //    // System.out.print(arm+" "+an);
    //     if(arm==an)
    //     System.out.print("Armstrong number");
    //     else
    //     System.out.print("Not Armstrong number");
    // while(num>0)
    // {
    //     num=num/10;
    //     count++;
    // }
    //     rem=(int)(sq%Math.pow(10,count));
    // if(rem==an)
    // {
    //     System.out.println("Automorphic number");
    // }
    // else
    // {
    //     System.out.println("Not Automorphic number");
    // }
    //num=div*divd+rem;
    //rem=num-div*divd;
    // int x=3,y=2;
    // int div=x/y;
    //  rem=x-(div*y);
    // System.out.println(rem);  this is code for modulus without using % operator
    


    }
}