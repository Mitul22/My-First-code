import java.util.Scanner;
class Loop1
{
    void Sum(int x,int y)
    {
        return (x+y);
    }
    void Sum(int x,int y,int z)
    {
        return (x+y+z);
    }
    public static void main(String args[])
    {
        
        // Scanner obj=new Scanner(System.in);
        // int n=obj.nextInt();
        // int i;
        // for(i=0;i<n;i++)
        // {
        //  System.out.println(i);
        // }
        Sum s=new Sum();
        System.out.print(s.Sum(10,20));
        System.out.print(s.Sum(30,40));
    }
}