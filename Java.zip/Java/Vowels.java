import java.util.Scanner;
class Vowels
{ 
   public static void main(String args[])  
   {
      Scanner obj=new Scanner(System.in);
      System.out.println("Enter a character=>\t");
      char vow=obj.next().charAt(0);
      String res=" ";
      switch(vow)
      {
       case 'a':
       res="Vowels";
       break;
       case 'e':
       res="Vowels";
       break;
       case 'i':
       res="Vowels";
       break;
       case 'o':
       res="Vowels";
       break;
       case 'u':
       res="Vowels";
       break;
       case 'A':
       res="Vowels";
       break;
       case 'E':
       res="Vowels";
       break;
       case 'I':
       res="Vowels";
       break;
       case 'O':
       res="Vowels";
       break;
       case 'U':
       res="Vowels";
       break;
       default:
       res="Consonants";
       break;
       }
       System.out.println(res);
}
}