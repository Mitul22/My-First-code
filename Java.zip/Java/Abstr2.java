abstract class Per
{
    public abstract void show();
   public Per()
   {
       System.out.println("This is from abstract classs");
   }
}
class Abstr2 extends Per
{
   public void show()
    {
        System.out.println("This is from extended class");
    }
    public static void main(String args[])
    {
        // Abstr obj=new Abstr();
        Per obj=new Abstr2();
        obj.show();
    }
}