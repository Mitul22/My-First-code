class Student
{
 int id;
 String name;
 public static void main(String args[])
 {
   Student S=new Student();
   System.out.println(S.id);
   System.out.println(S.name);
 }
}