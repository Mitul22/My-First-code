import java.util.Scanner;
class Check 
{
    public static void main(String args[])
    {
        Scanner obj=new Scanner(System.in);
        int n=obj.nextInt();
        int i;
        int [] use = new int [] {0,1,2,3,4,5,6,7,8,9,10,11};
        for(i=0;i<=9;i++)
        {
            use[n%10]=1;
            if(use[i]==1)
            {
                System.out.println(i);
            }
        }
        // if(use[i]==1)
        // {
        //     System.out.print(i);
        // }
    }
}