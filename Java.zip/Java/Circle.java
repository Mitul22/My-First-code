class Circle
{
    public static void main(String args[])
    {
        double r=2.5;
        System.out.print(Math.PI*(r*r));
    }
}