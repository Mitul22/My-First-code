package pac;
class Pacs
{
    void disp()
    {
        System.out.println("This is package 1");
    }
}
class Person
{
    void show()
   {
        System.out.println("This is package 2");
    }
}
