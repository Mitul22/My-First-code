import java.util.Scanner;
class Person
{
        
        String name;
        int age;
        Person(String name,int age)
        {
            this.name=name;
            this.age=age;
        }
}
class Citizen extends Person
{
    int marks;
    Citizen(String name,int age,int marks)
    {
        super(name,age);
        this.marks=marks;
    }
    void display()
    {
        System.out.print(name+" "+age+" "+marks);
    }
}
class Sup3 
{
    public static void main(String args[])
     {
         Citizen obj=new Citizen("Ram",23,90);
         obj.display();
     }
}