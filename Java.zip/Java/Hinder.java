import packs.Benz;
import packs2.Pheno;
class Hinder
{
    public static void main(String args[])
    {
        Pheno obj=new Pheno();
        obj.disp();
    }
}