import java.util.Scanner;
class Per 
{
    public static void main(String args[])
    {
    Scanner obj=new Scanner(System.in);
    Scanner obj1=new Scanner(System.in);
    String name=obj.nextLine();
    String color=obj.nextLine();
    int eyes=obj.nextInt();
    int deb=obj.nextInt();
    String n=obj1.nextLine();
    String c=obj1.nextLine();
    int e=obj1.nextInt();
    int d=obj1.nextInt();
    Actor o1=new Actor(name,color,eyes,deb);
    System.out.println(o1);
    Actress o2=new Actress(n,c,e,d);
    System.out.println(o2);
    }
}
class Actor extends Per
{
    String name;
    String color;
    int eyes;
    int deb;
   public Actor(String name,String color,int eyes,int deb)
    {
        this.name=name;
        this.color=color;
        this.eyes=eyes;
        this.deb=deb;
        // System.out.println("The person "+name+" is an actor."+" He has a "+color+" color"+" has "+eyes+" eyes"+" and debut year is "+deb);
    }
    public String toString()
    {
        return "The person "+name+" is an actor."+" He has a "+color+" color"+" has "+eyes+" eyes"+" and debut year is "+deb;
    }
}
class Actress extends Per
{
    String n;
    String c;
    int e;
    int d;
   public Actress(String n,String c,int e,int d)
    {
        this.n=n;
        this.c=c;
        this.e=e;
        this.d=d;
        //System.out.println("The person "+name+" is an actress."+" She has a "+color+" color"+" has "+eyes+" eyes"+" and debut year is "+deb);
    }
    public String toString()
    {
        return "The person "+n+" is an actress."+" She has a "+c+" color"+" has "+e+" eyes"+" and debut year is "+d;
    }
}
