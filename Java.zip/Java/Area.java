class  Area
{
 int radius;
 int length;
 public static void main(String args[])
 {
   Area R = new Area();
   Area L = new Area();
   Area B = new  Area();
   R.Area=4;
   L.Area=16;
   B.Area=12;
   Sytem.out.println();
  }
}
  