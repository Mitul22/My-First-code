import java.util.Scanner;
class Lists
{
    static char alphabetic(char d)
    {
        return d;
    }
    public static void main(String args[])
    {
        int count=0,c=0;
        String s="hello this is java language";
        char [] sa=s.toCharArray();
        for(int i=0;i<sa.length;i++)
        {
             if(sa[i]==' ')
             count++;
        }
        System.out.println(count);
        for(int i=0;i<sa.length;i++)
        {
            if(sa[i]!=' ')
            c++;
        }
        Lists obj=new Lists();
        System.out.print(c);
        System.out.println(Character.digit('a',26));
    }
}